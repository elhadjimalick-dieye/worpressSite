<?php
$conflicted_pages = array(
	"wp_rem_cs" => array(
		"About Us",
		"Home",
	),
);