<h2>
    Installed language files
</h2>
<p>
    This screen lists all files installed for the selected language.
</p>
<p>
    Only files from correctly configured bundles will show up here.
    If you don't see the files you expect, then locate the bundle in the Themes or Plugins section and ensure it's configured correctly.
</p>
