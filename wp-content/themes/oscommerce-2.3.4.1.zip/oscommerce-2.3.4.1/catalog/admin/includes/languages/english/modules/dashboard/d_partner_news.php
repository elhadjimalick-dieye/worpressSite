<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_TITLE', 'Partner News');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_DESCRIPTION', 'Show the lastest osCommerce Partner News');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_MORE_TITLE', 'See More Partner Services');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_ERROR_JSON_DECODE', 'PHP json_decode() function required.');
?>
