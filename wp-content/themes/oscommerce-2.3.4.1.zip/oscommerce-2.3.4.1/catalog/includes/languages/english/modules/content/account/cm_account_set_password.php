<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_TITLE', 'Set Account Password');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_DESCRIPTION', 'Replace Change Password page with Set Password page if no local account password has been set');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_LINK_TITLE', 'Set account password.');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_1', 'My Account');
  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_2', 'Set Password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_HEADING_TITLE', 'Set Password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_TITLE', 'Set Password');

  define('MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SUCCESS_PASSWORD_SET', 'Your password has been successfully saved.');
?>
