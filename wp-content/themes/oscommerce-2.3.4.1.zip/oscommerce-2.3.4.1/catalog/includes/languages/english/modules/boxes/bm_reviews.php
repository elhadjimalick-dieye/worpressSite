<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Reviews');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Show product reviews');
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Reviews');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Write a review on this product!');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'There are currently no product reviews');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s of 5 Stars!');
?>
